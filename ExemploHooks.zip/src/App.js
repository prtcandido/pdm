import { useState, useRef, useEffect } from "react";

function App() {
  const [x,setX] = useState(0)
  const y = useRef(0)
  useEffect( ()=>{console.log("A")}  , [] )
  console.log("B")
  return (
    <div>
      <h1>X: {x}</h1>
      <button onClick={ ()=>{setX(x+1)} }>
        B1
      </button>
      <button onClick={ ()=> y.current = y.current + 1  }>
        B2
      </button>
      <button onClick={ ()=> console.log(y.current)  }>
        B3
      </button>
    </div>
  );
}

export default App;
